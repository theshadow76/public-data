import requests

url = "https://broker-api.sandbox.alpaca.markets/v1/accounts/081157ad-db5d-4fde-8a81-c3476e6f85ec/recipient_banks"

payload = {
    "bank_code_type": "BIC",
    "name": "Banco Security",
    "bank_code": "BSCLCLRM",
    "account_number": "0 000 92 94175 2",
    "country": "CHL",
    "state_province": "Vitacura",
    "postal_code": "7630000",
    "city": "Santiago",
    "street_address": "Los Abetos 1561"
}
headers = {
    "accept": "application/json",
    "content-type": "application/json",
    "authorization": "Basic Q0tPV1FUTUZCNkRRU1JPV1A2MFc6cWpyRnVRTk01dU1lVldoOEFDWm5TZGZ6TnVCVDY4dDNJZjFZVDFTOA=="
}

response = requests.post(url, json=payload, headers=headers)

print(response.text)