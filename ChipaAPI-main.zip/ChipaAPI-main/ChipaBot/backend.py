# Made by © Vigo Walker

import sqlite3
import uuid
from cryptography.fernet import Fernet
import requests
import jwt
import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import auth
from openai import OpenAI

# locals
from helpers.firebase_helper import FireBaseHelping

class Profile:
    def __init__(self, app) -> None:
        self.cx = sqlite3.connect("chipa.db", check_same_thread=False)
        self.PRIVATE_KEY = os.getenv("CHIPA_PRIVATE_KEY_ADD_PROFILE")
        self.default_app = app
        self.db = firestore.client()
        self.fbh = FireBaseHelping(app=self.default_app)
    def GetProfile(self, UID):
        user = auth.get_user(UID)
        return user
    def CreateProfile(self, name, email, password):
        try:
            user = auth.create_user(
                email=email,
                email_verified=False,
                # phone_number='+56979336792',
                password=password,
                display_name=name,
                # photo_url='https://img.freepik.com/free-vector/gradient-stock-market-concept_23-2149166910.jpg?size=626&ext=jpg&ga=GA1.1.1224184972.1715040000&semt=ais',
                disabled=False)
            print('Sucessfully created new user: {0}'.format(user.uid))

            UID = user.uid

            self.fbh.CreateUserFirestore(email, password, name, 10000, True, False, UID)

            return 'Sucessfully created new user: {0}'.format(user.uid)
        except Exception as e:
            print(f"error: {e}")
            return e
    def SQLExecuter(self, command):
        data = self.cx.execute(command)
        self.cx.commit()
        return {"Message" : data.fetchone()}
    def AddBalance(self, uid: str, balance: float):
        command = f"INSERT INTO Balance (uid, balance) VALUES (?, ?)"
        data = self.cx.execute(command, (uid, balance))
        self.cx.commit()
        return {"Sample data": data, "PreProcessed data": data.fetchone(), "Message" : "Success"}
    def CreateUID(self, email, password):
        data = {
            "email": email,
            "password": password
        }
        print(f"private key = {self.PRIVATE_KEY}") # TODO: Remove this
        token = jwt.encode(payload=data, key=str(self.PRIVATE_KEY), algorithm="HS256")
        return token
    def GetBalance(self, uid):
        data = self.fbh.GetBalance(uid)
        return data
class Trading:
    def __init__(self, app) -> None:
        self.url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&locale=en"
        self.cx = sqlite3.connect("chipa.db", check_same_thread=False)
        self.db = firestore.client()
        self.app = app
        self.fbh = FireBaseHelping(app=app)
    def GetCoins(self):
        response = requests.get(self.url)
        data = response.json()
        return data
    def BuyCrypto(self, uid, amount_crypto, amount_usd, type, CryptoID):
        tradeid = str(uuid.uuid4())
        prfl = Profile(app=self.app)
        data3 = prfl.GetBalance(uid=uid)
        balance = data3 - amount_usd


        # NOTE: Esto lo tengo por ahora asi, sera mas usado en el futuro
        response = requests.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&locale=en")
        crypto_price = response.json()
        crypto_price_real = None
        if response.status_code == 200:
            for i in crypto_price:
                if i['id'] == id:
                    crypto_price_real = i['current_price']
        
        # TODO: Hacer el algoritmo para conseguir cuanto el usuario esta gastando:
        #       - primero el usuario va decir cuanto esta invirtienda en esa crypto, es decir, si por ejemplo invierto en BTC y BTC esta a 48k USD, digo que quiero comprar 1000 USD worth del BTC
        #         Eso significaria que compro 0.000022BTC, pero el tema es conseguir ese numero
        
        amount = amount_usd

        command = f"INSERT INTO CryptoTrading (uid, tradeid, amount, type) VALUES (?, ?, ?, ?)" # TODO: Añadir el crypto_name aqui
        command2 = f"UPDATE Balance SET balance = ? WHERE uid = ?"
        data = self.cx.execute(command, (uid, tradeid, amount, type))
        data2 = self.cx.execute(command2, (balance, uid))

        self.cx.commit()

        dt = self.fbh.CreateTrade(uid=uid, amount_usd=amount, CryptoID=CryptoID, demo=True, type=type, balance=balance)

        return {"Message" : "Success", "data" : str(dt)}

    def SellCrypto(self, uid, amount_crypto, amount_usd, type, CryptoID):
        tradeid = str(uuid.uuid4())
        prfl = Profile()
        data3 = prfl.GetBalance(uid=uid)
        balance2 = data3['Balance']
        balance = balance2 + amount_usd

        amount = amount_usd

        command = f"INSERT INTO CryptoTrading (uid, tradeid, amount, type) VALUES (?, ?, ?, ?)" # TODO: Añadir el crypto_name aqui
        command2 = f"UPDATE Balance SET balance = ? WHERE uid = ?"
        data = self.cx.execute(command, (uid, tradeid, amount, type))
        data2 = self.cx.execute(command2, (balance, uid))

        self.cx.commit()

        return {"Message" : "Success"}

class _db_helper:
    def __init__(self) -> None:
        self.cx = sqlite3.connect("chipa.db", check_same_thread=False)
    def CreateTable(self, tbl_name: str, tbl_columns: dict = None):
        command = f"CREATE TABLE {tbl_name}(uid, tradeid, amount, type)"
        self.cx.commit()
        self.cx.execute(command)
    def CreateUID(self):
        return uuid.uuid4()

class _Admin_helper:
    def __init__(self) -> None:
        self.key = Fernet.generate_key()
        self.fernet = Fernet(key=self.key)
    def str_to_binary(self, string):
        # Initialize empty list to store binary values
        binary_list = []
        
        # Iterate through each character in the string
        for char in string:
            # Convert character to binary, pad with leading zeroes and append to list
            binary_list.append(bin(ord(char))[2:].zfill(8))
            
        # Join the binary values in the list and return as a single string
        return ''.join(binary_list)
    def SaveData(self, data):
        message = str(data)
        with open("Admin.data", 'w') as f:
            f.write(self.str_to_binary(string=message))
        return self.str_to_binary(string=message)

class AImodel():
    def __init__(self) -> None:
        pass
    def chat(self, message):
        client = OpenAI(api_key="sk-proj-VZ0A4zLaadHtU4sJ4MT9T3BlbkFJKCOABsiDtim3zHdw8Ue6")

        docs = None
        with open("Chipa_DSL_Documentation.txt", "r") as f:
            docs = f.read()

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": f"you are a bot that needs to code what the user asks you, you will be using a custom language, here are the docs: {docs} and provide it as string without the '```'"},
                {"role": "user", "content": message},
            ]
        )
        return response.choices[0].message.content