import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import auth
import uuid

class FireBaseHelping:
    def __init__(self, app) -> None:
        cred = credentials.Certificate("chipa-e1299-firebase-adminsdk-f0207-638d168490.json")
        self.db = firestore.client()
        self.app = app
    def CreateUserFirestore(self, email: str = "", passwordhash: str = "", name: str = "", initbalance: float = 10000.0, demo: bool = True, verified: bool = False, UID: str = ""):
        users_ref = self.db.collection("Users").document(UID)

        data = {
            "email" : email,
            "passwordhash" : passwordhash,
            "name" : name,
            "initbalance" : initbalance,
            "demo" : demo,
            "verified" : verified,
            "uid" : UID
        }

        print(users_ref.set(data))
        return True
    def UpdateUserFirestore(self, UID: str, email: str = None, passwordhash: str = None, name: str = None, initbalance: float = None, demo: bool = None, verified: bool = None):
        users_ref = self.db.collection("Users").document(UID)

        # Create a dictionary of fields to update
        data = {}
        if email is not None:
            data["email"] = email
        if passwordhash is not None:
            data["passwordhash"] = passwordhash
        if name is not None:
            data["name"] = name
        if initbalance is not None:
            data["initbalance"] = initbalance
        if demo is not None:
            data["demo"] = demo
        if verified is not None:
            data["verified"] = verified

        # Update the document with the provided fields
        if data:
            users_ref.update(data)
            print(f"User {UID} updated with data: {data}")
            return True
        else:
            print(f"No data provided to update for user {UID}")
            return False
        
    def UpdateUserBalance(self, UID: str, new_balance: float):
        users_ref = self.db.collection("Users").document(UID)

        # Create a dictionary to update the balance
        data = {
            "initbalance": new_balance
        }

        # Update the document with the new balance
        users_ref.update(data)
        print(f"User {UID} balance updated to: {new_balance}")
        return True


    def GetBalance(self, uid, demo: bool = True):
        users_ref = self.db.collection("Users").document(uid)

        doc = users_ref.get()

        if doc.exists:
            return doc.to_dict()['initbalance']
        else:
            return None
    def CreateTrade(self, uid, amount_usd, type, CryptoID, demo, balance):
        TradeID = uuid.uuid4()
        trades_ref = self.db.collection("Trades").document(f"User_{uid}_-_{TradeID}_")

        data = {
            "uid" : uid,
            "CryptoID" : CryptoID,
            "amount_usd" : amount_usd,
            "type" : type,
            "demo" : demo,
            "TradeID" : str(TradeID)
        }

        dt = trades_ref.set(data)
        print(dt)

        # update balance
        self.UpdateUserBalance(UID=uid, new_balance=balance)

        return dt



# cred = credentials.Certificate("chipa-e1299-firebase-adminsdk-f0207-638d168490.json")
# default_app = firebase_admin.initialize_app(credential=cred)

# fbh = FireBaseHelping(default_app)
# fbh.CreateUserFirestore("vigopaulesmuypro@hjha.com", "UkVEQUNURUQ=", "wigo", 10000, True, False, "XhaMaNs0BNZu1TsJeS1fLy2Qdrq2")
# print(fbh.GetBalance("XhaMaNs0BNZu1TsJeS1fLy2Qdrq2"))
# fbh.CreateTrade("XhaMaNs0BNZu1TsJeS1fLy2Qdrq2", 100, "Buy", "BTCUSDT", True)