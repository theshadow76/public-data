from tradingview_ta import TA_Handler, Interval, Exchange
import tradingview_ta

from content import Indicators

class NormalIndicators:
    def __init__(self) -> None:
        self.availableindicators = Indicators().AVAILABLES
        self.intervals = {
            "1m": Interval.INTERVAL_1_MINUTE,
            "5m": Interval.INTERVAL_5_MINUTES,
            "15m": Interval.INTERVAL_15_MINUTES,
            "1h": Interval.INTERVAL_1_HOUR,
            "2h": Interval.INTERVAL_2_HOURS,
            "4h": Interval.INTERVAL_4_HOURS,
            "1d": Interval.INTERVAL_1_DAY
        }
    def RSI(self, ticker, timeframe, exchange, screener):
        interval2 = self.intervals.get(timeframe)
        asset = TA_Handler(
            symbol=ticker,
            screener=screener,
            exchange=exchange,
            interval=interval2
        )

        return asset.get_indicators(["RSI"])
    def BB(self, ticker, timeframe, exchange, screener):
        interval2 = self.intervals.get(timeframe)
        asset = TA_Handler(
            symbol=ticker,
            screener=screener,
            exchange=exchange,
            interval=interval2
        )

        return asset.get_indicators(["BB.lower", "BB.upper", "BBPower"])
    def Price(self, ticker, timeframe, exchange, screener):
        try:
            interval2 = self.intervals.get(timeframe)
            asset = TA_Handler(
                symbol=ticker,
                screener=screener,
                exchange=exchange,
                interval=interval2
            )

            data = asset.get_indicators(["close"])

            return {
                "StatusCode" : 200,
                "data" : data
            }
        except Exception as e:
            return {
                "StatusCode" : 400,
                "error" : e
            }
    def EMA(self, ticker, timeframe, exchange, screener):
        try:
            interval2 = self.intervals.get(timeframe)
            if interval2 is None:
                raise ValueError("Invalid timeframe provided.")

            asset = TA_Handler(
                symbol=ticker,
                screener=screener,
                exchange=exchange,
                interval=interval2
            )

            data = asset.get_indicators([
                "EMA10",
                "EMA100",
                "EMA20",
                "EMA200",
                "EMA30",
                "EMA5",
                "EMA50"
            ])

            return {
                "StatusCode": 200,
                "data": data
            }
        except ValueError as ve:
            return {
                "StatusCode": 400,
                "Error": str(ve)
            }
        except Exception as e:
            error_message = str(e)
            if "Exchange or symbol not found" in error_message:
                return {
                    "StatusCode": 404,
                    "Error": "We did not find the symbol you searched for."
                }
            else:
                return {
                    "StatusCode": 400,
                    "Error": error_message
                }
    def SMA(self, ticker, timeframe, exchange, screener):
        interval2 = self.intervals.get(timeframe)
        asset = TA_Handler(
            symbol=ticker,
            screener=screener,
            exchange=exchange,
            interval=interval2
        )

        return asset.get_indicators([  "SMA10",
  "SMA100",
  "SMA20",
  "SMA200",
  "SMA30",
  "SMA5",
  "SMA50"])
    def GetAvailableIndicators(self):
        return self.availableindicators
    def GetSentiment(self, symbol, screener, exchange, interval):
        interval2 = self.intervals.get(interval)
        if interval2 is None:
            return "Please select one of this timeframes: 1m, 5m, 15m, 1h, 2h, 4h, 1d"
            
        asset = TA_Handler(
            symbol=symbol,
            screener=screener,
            exchange=exchange,
            interval=interval2
        )

        return asset.get_analysis().summary
