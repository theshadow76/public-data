import ply.lex as lex
import ply.yacc as yacc
import requests
tokens = (
    'CLASS', 'DEF', 'IDENTIFIER', 'LBRACE', 'RBRACE', 'LPAREN', 'RPAREN',
    'COMMA', 'COLON', 'EQUALS', 'NUMBER', 'STRING', 'SOURCE', 'PERIOD',
    'IF', 'OPERATOR', 'ACTION', 'BOOLEAN', 'LBRACKET', 'RBRACKET', 'INDICATOR'
)

t_CLASS = r'class'
t_DEF = r'def'
t_IDENTIFIER = r'[a-zA-Z_][a-zA-Z_0-9]*'
t_LBRACE = r'\{'
t_RBRACE = r'\}'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_COMMA = r','
t_COLON = r':'
t_EQUALS = r'='
t_SOURCE = r'close|open|high|low'
t_IF = r'if'
t_OPERATOR = r'>|<'
t_ACTION = r'buy|sell'
t_LBRACKET = r'\['
t_RBRACKET = r'\]'
t_ignore = ' \t'

def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    return t

def t_STRING(t):
    r'\".*?\"'
    t.value = t.value.strip('\"')
    return t

def t_BOOLEAN(t):
    r'true|false'
    t.value = True if t.value == 'true' else False
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_error(t):
    print(f"Illegal character '{t.value[0]}'")
    t.lexer.skip(1)

lexer = lex.lex()

def p_statement_class(p):
    'statement : class_definition'
    p[0] = p[1]

def p_statement_function(p):
    'statement : function_definition'
    p[0] = p[1]

def p_statement_variable(p):
    'statement : variable_assignment'
    p[0] = p[1]

def p_statement_json(p):
    'statement : json_definition'
    p[0] = p[1]

def p_statement_dict(p):
    'statement : dict_definition'
    p[0] = p[1]

def p_statement_expr(p):
    'statement : expression'
    p[0] = p[1]


def p_class_definition(p):
    'class_definition : CLASS IDENTIFIER LBRACE class_body RBRACE'
    p[0] = ('class', p[2], p[4])

def p_class_body(p):
    'class_body : statement_list'
    p[0] = p[1]

def p_statement_list(p):
    '''statement_list : statement
                      | statement_list statement'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_function_definition(p):
    'function_definition : DEF IDENTIFIER LPAREN parameters RPAREN LBRACE function_body RBRACE'
    p[0] = ('function', p[2], p[4], p[7])

def p_variable_assignment(p):
    'variable_assignment : IDENTIFIER EQUALS expression'
    p[0] = ('assign', p[1], p[3])

def p_json_definition(p):
    'json_definition : IDENTIFIER EQUALS json'
    p[0] = ('json', p[1], p[3])

def p_dict_definition(p):
    'dict_definition : IDENTIFIER EQUALS dict'
    p[0] = ('dict', p[1], p[3])

def p_parameters(p):
    '''parameters : IDENTIFIER
                  | parameters COMMA IDENTIFIER
                  | empty'''
    if len(p) == 2:
        p[0] = [p[1]]
    elif len(p) == 4:
        p[0] = p[1] + [p[3]]
    else:
        p[0] = []

def p_function_body(p):
    'function_body : statement_list'
    p[0] = p[1]

def p_statement_list(p):
    '''statement_list : statement
                      | statement_list statement'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_expression_variable(p):
    'expression : variable'
    p[0] = p[1]

def p_expression_json(p):
    'expression : json'
    p[0] = p[1]

def p_expression_dict(p):
    'expression : dict'
    p[0] = p[1]

def p_expression_indicator(p):
    'expression : INDICATOR LPAREN SOURCE COMMA NUMBER RPAREN'
    p[0] = ('indicator', p[1], p[3], p[5])

def p_expression_condition(p):
    'expression : IF expression OPERATOR expression ACTION'
    p[0] = ('condition', p[2], p[3], p[4], p[5])

def p_expression_value(p):
    '''expression : NUMBER
                  | STRING
                  | BOOLEAN'''
    p[0] = p[1]

def p_variable(p):
    'variable : IDENTIFIER'
    p[0] = ('variable', p[1])

def p_json(p):
    'json : LBRACKET json_body RBRACKET'
    p[0] = p[2]

def p_json_body(p):
    '''json_body : json_pair
                 | json_body COMMA json_pair'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

def p_json_pair(p):
    'json_pair : STRING COLON expression'
    p[0] = (p[1], p[3])

def p_dict(p):
    'dict : LBRACE dict_body RBRACE'
    p[0] = p[2]

def p_dict_body(p):
    '''dict_body : dict_pair
                 | dict_body COMMA dict_pair'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

def p_dict_pair(p):
    'dict_pair : IDENTIFIER COLON expression'
    p[0] = (p[1], p[3])

def p_empty(p):
    'empty :'
    p[0] = None

def p_error(p):
    print(f"Syntax error at '{p.value}'")

parser = yacc.yacc()
class Interpreter:
    def __init__(self):
        self.global_scope = {}
        self.class_definitions = {}
        self.functions = {}

    def evaluate(self, tree, scope=None):
        if scope is None:
            scope = self.global_scope

        if tree is None:
            return None

        if tree[0] == 'class':
            self.define_class(tree)
        elif tree[0] == 'function':
            self.define_function(tree)
        elif tree[0] == 'assign':
            self.assign_variable(tree, scope)
        elif tree[0] == 'json':
            self.assign_json(tree, scope)
        elif tree[0] == 'dict':
            self.assign_dict(tree, scope)
        else:
            return self.execute(tree, scope)

    def define_class(self, tree):
        _, class_name, class_body = tree
        self.class_definitions[class_name] = class_body
        for statement in class_body:
            if statement[0] == 'function':
                self.functions[f"{class_name}.{statement[1]}"] = statement[2], statement[3]

    def define_function(self, tree):
        _, function_name, parameters, function_body = tree
        self.functions[function_name] = (parameters, function_body)

    def assign_variable(self, tree, scope):
        _, var_name, expression = tree
        scope[var_name] = self.evaluate(expression, scope)

    def assign_json(self, tree, scope):
        _, var_name, json_body = tree
        scope[var_name] = {pair[0]: self.evaluate(pair[1], scope) for pair in json_body}

    def assign_dict(self, tree, scope):
        _, var_name, dict_body = tree
        scope[var_name] = {pair[0]: self.evaluate(pair[1], scope) for pair in dict_body}

    def execute(self, tree, scope):
        if tree[0] == 'indicator':
            return self.evaluate_indicator(tree, scope)
        elif tree[0] == 'condition':
            return self.evaluate_condition(tree, scope)
        elif tree[0] == 'function_call':
            return self.call_function(tree, scope)
        elif tree[0] == 'variable':
            return scope.get(tree[1])
        elif tree[0] == 'json':
            return {pair[0]: self.evaluate(pair[1], scope) for pair in tree[1]}
        elif tree[0] == 'dict':
            return {pair[0]: self.evaluate(pair[1], scope) for pair in tree[1]}
        elif isinstance(tree, (int, str, bool)):
            return tree

    def evaluate_indicator(self, tree, scope):
        _, name, source, period = tree
        if name == 'SMA':
            return self.sma(source, period)
        elif name == 'RSI':
            return self.rsi(source, period)

    def evaluate_condition(self, tree, scope):
        _, ind1, op, ind2, action = tree
        ind1_val = self.evaluate(ind1, scope)
        ind2_val = self.evaluate(ind2, scope)
        if op == '>' and ind1_val > ind2_val:
            return self.execute_action(action, scope)
        elif op == '<' and ind1_val < ind2_val:
            return self.execute_action(action, scope)

    def call_function(self, tree, scope):
        _, function_name, arguments = tree

        # Check if it's a method call within a class
        if '.' in function_name:
            class_name, method_name = function_name.split('.')
            if class_name in self.class_definitions:
                class_body = self.class_definitions[class_name]
                for statement in class_body:
                    if statement[0] == 'function' and statement[1] == method_name:
                        parameters, function_body = statement[2], statement[3]
                        local_scope = {param: self.evaluate(arg, scope) for param, arg in zip(parameters, arguments)}
                        for statement in function_body:
                            self.evaluate(statement, local_scope)
                        return
                print(f"Method '{method_name}' not found in class '{class_name}'.")
            else:
                print(f"Class '{class_name}' not defined.")
        else:
            print(f"Invalid function call format: '{function_name}'.")

    def execute_action(self, action, scope):
        if action == 'buy':
            print("Executing Buy Action")
        elif action == 'sell':
            print("Executing Sell Action")

    def sma(self, source, period):
        # Placeholder for SMA calculation
        pass

    def rsi(self, source, period):
        data = requests.get(f"http://127.0.0.1:8000/indicators/rsi?ticker=BTCUSDT&timeframe={period}&screener=crypto&exchange=BINANCE")
        return data.json()['response']['rsi']

interpreter = Interpreter()

user_input = """
class RSI_Trading_Strategy {
    def trade_RSI_strategy() {
        if RSI(close, 14) > 80 sell
        if RSI(close, 14) < 20 buy
    }
}
"""

# Assuming your lexer and parser setup is correct before this point
lexer.input(user_input)
tokens = [token for token in lexer]
parse_tree = parser.parse(user_input)
interpreter.evaluate(parse_tree)

# To call a function within the defined class:
function_call = ('function_call', 'RSI_Trading_Strategy.trade_RSI_strategy', [])
interpreter.execute(function_call, interpreter.global_scope)