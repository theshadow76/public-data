# Chipa

## Todo
- transferir de SQLite a Firebase
- hacer todo el systema demo
- integrar Firebase con Alpaca API

## FireBase Todo's
- convertir el passwordhash en hash de verdad no el pwd del usuario
- hacer el DB para la parte del trading