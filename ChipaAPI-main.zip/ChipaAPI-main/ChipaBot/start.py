import subprocess

def init():
    subprocess.run(r"cd E:/DiscordBots/ChipaBot && uvicorn app2:app --port 8900", shell=True)
