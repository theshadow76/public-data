import requests

url = "https://broker-api.sandbox.alpaca.markets/v1/accounts/081157ad-db5d-4fde-8a81-c3476e6f85ec/transfers"

payload = {
    "transfer_type": "wire",
    "direction": "INCOMING",
    "timing": "immediate",
    "amount": "1000"
}
headers = {
    "accept": "application/json",
    "content-type": "application/json",
    "authorization": "Basic Q0tPV1FUTUZCNkRRU1JPV1A2MFc6cWpyRnVRTk01dU1lVldoOEFDWm5TZGZ6TnVCVDY4dDNJZjFZVDFTOA=="
}

response = requests.post(url, json=payload, headers=headers)

print(response.text)