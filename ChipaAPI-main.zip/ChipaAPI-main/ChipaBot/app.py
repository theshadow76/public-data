# Made by © Vigo Walker
# This is a personal project that is not aimed to be used in the real life, as all of this is complety fake, all though it does uses third party API's,
# That doesn't mean that this API can be used in a real world example,
# if you have any questions or need support, please reach me at vigopaul05@gmail.com or on my instagram @vigo_walker

from typing import Optional
from fastapi import FastAPI, Body, Request, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBearer
from fastapi.security.http import HTTPAuthorizationCredentials
import requests
import firebase_admin
from firebase_admin import credentials

from content import Html

from backend import Profile, Trading, AImodel

from indicators import NormalIndicators

app = FastAPI()
app.title = "Chipa API"

cred = credentials.Certificate("chipa-e1299-firebase-adminsdk-f0207-638d168490.json")
default_app = firebase_admin.initialize_app(credential=cred)

prfl = Profile(default_app)
trading = Trading(default_app)
indicators = NormalIndicators()
ai = AImodel()

class JWTBearer(HTTPBearer):
    async def __call__(self, request: Request) -> HTTPAuthorizationCredentials | None:
        return await super().__call__(request)

@app.get('/', tags=['Home'])
def root():
    """Root call"""
    return HTMLResponse(content=Html.ROOT_HTML, status_code=200)


# -------------------------------------------- profile -------------------------------------------- #

@app.get('/demo/porfile', tags=['Profile'], summary="Get the profile of the user")
def GetProfile(uid):
    """GET profile data, Example usage: https://chipa.api.vigodev.net/profile?id={UID}"""
    data = prfl.GetProfile(UID=uid)
    return {"Message" : data}

@app.post('/demo/profile/add', tags=['Profile'], summary="Create profile")
def CreateProfile(name: str = Body(), email: str = Body(), password: str = Body()):
    """Create a profile"""
    data = prfl.CreateProfile(name=name, email=email, password=password)
    token = prfl.CreateUID(email=email, password=password)
    return JSONResponse(content={"Message" : "Done", "data" : data}, status_code=200)

@app.put('/demo/porfile/edit', tags=['Profile'], summary="Edit profile")
def EditProfile(id: str = Body(), name: str = Body(), email: str = Body(), password: str = Body()):
    """Edit profile"""
    return "Profile Edited"

@app.delete('/demo/profile/delete', tags=['Profile'], summary="Delete profile")
def DeleteProfile(id):
    """Delete Profile"""
    return "Profile Deleted"


# -------------------------------------------- Trading -------------------------------------------- #
# TODO:
#   GetCryptoByID --> GET - NotDone
#   GetAllCryptosIDs --> GET - NotDone
#   GetAllCryptos --> GET - NotDone
#   GetBalance --> GET - Done
#   GetCryptoPrice --> GET - NotDone
#   GetProfitByID --> GET - NotDone
#   GetAllProfit --> GET - NotDone
#   GetTradeHistory --> GET - NotDone
#   GetOpenOptions --> GET - NotDone
#   BuyCrypto --> POST - NotDone
#   SellCrypto --> POST - NotDone
#   AddBalance --> POST - NotDone

@app.get('/demo/trading/GetCryptoByID/{id}', tags=['Trading'], summary="Get the crypto by it's ID")
def GetCryptoByID(id):
    """Get Crypto By it's ID"""
    try:
        response = requests.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&locale=en")
        data = response.json()
        if response.status_code == 200:
            for i in data:
                if i['id'] == id:
                    return JSONResponse(content=i, status_code=200)
            return JSONResponse(content=f"No crypto found for id: {id}", status_code=404)
        return JSONResponse(content="Something when wrong", status_code=response.status_code)
    except Exception as e:
        return JSONResponse(content=f"A error ocured: {e}", status_code=400)

@app.get('/demo/trading/GetAllCryptosIDs', tags=['Trading'], summary="Get all the cryptos id's")
def GetAllCryptosIDs():
    """Get all the cryptos id's"""
    response = requests.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&locale=en")
    data = response.json()
    ALLDATA = []
    if response.status_code == 200:
        for i in data:
            ALLDATA.append({"id" : i['id'], "name" : i['name']})
        return JSONResponse(content=ALLDATA, status_code=response.status_code)
    else:
        return JSONResponse(content={"error" : "A error ocured"}, status_code=response.status_code)

@app.get('/demo/trading/GetAllCryptos', tags=['Trading'], summary="Get all the crypto")
def GetAllCryptos():
    """Get all the crypto"""
    try:
        response = requests.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&locale=en")
        data = response.json()
        return JSONResponse(content=data, status_code=response.status_code)
    except Exception as e:
        return JSONResponse(content=f"A error ocured: {e}", status_code=400)

@app.get('/demo/trading/GetBalance', tags=['Trading'], summary="Get the balance")
def GetBalance(uid, demo: bool = True):
    """Get the balance"""
    data = prfl.GetBalance(uid=uid)
    return JSONResponse(content={"Balance" : data})

@app.get('/demo/trading/GetCryptoPrice', tags=['Trading'], summary="Get the crypto price")
def GetCryptoPrice(id):
    """Get the crypto price"""
    response = requests.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&locale=en")
    data = response.json()
    try:
        if response.status_code == 200:
            for i in data:
                if i['id'] == id:
                    return JSONResponse(content={"Price" : i['current_price']}, status_code=200)
            return JSONResponse(content='Crypto with that ID was not found', status_code=404)
    except Exception as e:
        return JSONResponse(content=f"A error ocured: {e}", status_code=response.status_code)

@app.get('/demo/trading/GetProfitByID', tags=['Trading'], summary="Get the profit of a specific trade")
def GetProfitByID(id):
    """Get the proift of a specific trade"""
    return "GetProfitByID"

@app.get('/demo/trading/GetAllProfit', tags=['Trading'], summary="Get all the profit")
def GetAllProfit():
    """Get all the profit"""
    return "GetAllProfit"

@app.get('/demo/trading/GetTradeHistory', tags=['Trading'], summary="Get the trade history")
def GetTradeHistory():
    """Get the trade history"""
    return "GetTradeHistory"

@app.get('/demo/trading/GetOpenOptions', tags=['Trading'], summary="Get the open options")
def GetOpenOptions():
    """Get the open options"""
    return "GetOpenOptions"

@app.post('/demo/trading/BuyCrypto', tags=['Trading'], summary="Buy crypto")
def BuyCrypto(CryptoID: str = Body(), amount: float = Body(), uid: str = Body()):
    """Buy crypto"""
    data = trading.BuyCrypto(uid=uid, amount_crypto=1, amount_usd=amount, type="buy", CryptoID=CryptoID)
    return data

@app.post('/demo/trading/SellCrypto', tags=['Trading'], summary="Sell crypto")
def SellCrypto(CryptoID: str = Body(), amount: float = Body(), uid: str = Body()):
    """Sell Crypto"""
    data = trading.SellCrypto(uid=uid, amount_crypto=1, amount_usd=amount, type="sell", CryptoID=CryptoID)
    return data

@app.post('/demo/trading/AddBalance', tags=['Trading'], summary="Add balance")
def AddBalance(amount: float = Body(), uid: str = Body()):
    """Add Balance"""
    prfl = Profile(app=default_app)
    prfl.AddBalance(uid=uid, balance=amount)
    return JSONResponse(content="Added balance!")

# -------------------------------------------- Admin -------------------------------------------- #
@app.post('/demo/admin/trading/crypto/add', tags=['Admin'], dependencies=[Depends(JWTBearer())])
def AddCrypto(token):
    """Add crypto"""
    if token == "4d0dacb16570b8c82b6bd5bd01342dd2b7b63c7bf95b9e9bbe2d41eca8bf59d61820b161d596693443d7e2ea84f1a3a6abddeb9b6eb0c1730b8910db53b2a04f":
        return "Authenticated"
    return "Not authenticated"

# -------------------------------------------- Brokers PocketOption -------------------------------------------- #
@app.get("/brokers/pocketoption/account/view", tags=["brokers", "pocketoption"], summary="PocketOption API integration [GET METHOD] | Get account")
def GetPocketOptionAPIaccount(id: str):   
    return id

@app.post("/brokers/pocketoption/account/add", tags=["brokers", "pocketoption"], summary="PocketOption API integration [POST METHOD] | Create Account")
def CreatePocketOptionAPIaccount(ssid: str = Body()):
    return ssid

@app.post("/brokers/pocketoption/connect", tags=["brokers", "pocketoption"], summary="PocketOption API integration [POST METHOD] | Connect")
def ConnectPocketOption(ssid: str = Body()):
    return ssid

@app.get("/brokers/pocketoption/getbalance", tags=["brokers", "pocketoption"], summary="PocketOption API integration [GET METHOD] | Get Balance")
def GetBalancePocketOptionAPI(ssid: str):
    return {"Balance" : 10000}

@app.post("/borkers/pocketoption/buy", tags=["brokers", "pocketoption"], summary="PocketOption API integration [POST METHOD] | Buy")
def BuyPocketOptionAPI(amount: int = Body(), active: str = Body(), expirations: list = Body(), ssid: str = Body()):
    return {
        "amount" : amount,
        "active" : active,
        "expirations" : expirations
    }

@app.get("/brokers/pocketoption/check_win", tags=["brokers", "pocketoption"], summary="PocketOption API integration [GET METHOD] | Check win")
def CheckWinPocketOptionAPI(ssid: str):
    return ssid

@app.get("/brokers/pocketoption/get_candles", tags=["brokers", "pocketoption"], summary="PocketOption API integration [GET METHOD] | Get candles")
def GetCandlesPocketOptionAPI(ssid: str):
    return ssid

# -------------------------------------------- Indicators -------------------------------------------- #

@app.get("/indicators/rsi", tags=["indicators"], summary="RSI indicator")
def GetRSI(ticker: str, timeframe: str, screener: str, exchange: str):
    data = indicators.RSI(ticker=ticker, timeframe=timeframe, exchange=exchange, screener=screener)
    return {
        "StatusCode" : 200,
        "Indicator" : "RSI",
        "exchange" : exchange,
        "TimeFrame" : timeframe,
        "coin" : ticker,
        "response" : data
    }

@app.get("/indicators/sentiment", tags=["indicators"], summary="Get the market sentiment")
def GetSentiment(ticker: str, timeframe: str, screener: str, exchange: str):
    data = indicators.GetSentiment(symbol=ticker, screener=screener, exchange=exchange, interval=timeframe)
    return data

@app.get("/indicators/all", tags=["indicators"], summary="All indicators")
def GetAllIndicators():
    data = indicators.GetAvailableIndicators()
    return data

@app.get("/indicators/bb", tags=["indicators"], summary="RSI indicator")
def GetBB(ticker: str, timeframe: str, screener: str, exchange: str):
    data = indicators.BB(ticker=ticker, timeframe=timeframe, exchange=exchange, screener=screener)
    return {
        "StatusCode" : 200,
        "Indicator" : "Bollinger Bands",
        "exchange" : exchange,
        "TimeFrame" : timeframe,
        "coin" : ticker,
        "response" : data
    }

@app.get("/indicators/sma", tags=["indicators"], summary="SMA indicator")
def GetSMA(ticker: str, timeframe: str, screener: str, exchange: str):
    data = indicators.SMA(ticker=ticker, timeframe=timeframe, exchange=exchange, screener=screener)
    return {
        "StatusCode" : 200,
        "Indicator" : "Simple Moving Average",
        "exchange" : exchange,
        "TimeFrame" : timeframe,
        "coin" : ticker,
        "response" : data
    }

@app.get("/indicators/price", tags=["indicators"], summary="Price indicator")
def GetPrice(ticker: str, timeframe: str, screener: str, exchange: str):
    data = indicators.Price(ticker=ticker, timeframe=timeframe, exchange=exchange, screener=screener)
    return {
        "StatusCode" : 200,
        "Indicator" : "Price",
        "exchange" : exchange,
        "TimeFrame" : timeframe,
        "coin" : ticker,
        "response" : data
    }

@app.get("/indicators/ema", tags=["indicators"], summary="ema indicator")
def GetEMA(ticker: str, timeframe: str, screener: str, exchange: str):
    data = indicators.EMA(ticker=ticker, timeframe=timeframe, exchange=exchange, screener=screener)
    if data['StatusCode'] == 200:
        return {
        "StatusCode" : 200,
        "Indicator" : "Exponatial Moving Average",
        "exchange" : exchange,
        "TimeFrame" : timeframe,
        "coin" : ticker,
        "response" : data
    }
    else:
        if data["StatusCode"] == 404:
            msg = {
                "StatusCode" : 404,
                "Error" : data["Error"]
            }
            return JSONResponse(content=msg, status_code=404)
        else:
            msg = {
                "StatusCode" : 400,
                "Error" : data["Error"]
            }
            return JSONResponse(content=msg, status_code=400)

@app.post("/tests/ai", tags=["tests"], summary="Ai test")
def GetAllIndicators(message: str = Body()):
    data = ai.chat(message)
    return data