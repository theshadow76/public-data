"""Module for IQ Option API websocket objects."""
